Execute the scripts in the following order:

1. create_gggs.sql
2. constraints_gggs.sql
3. load_gggs.sql



